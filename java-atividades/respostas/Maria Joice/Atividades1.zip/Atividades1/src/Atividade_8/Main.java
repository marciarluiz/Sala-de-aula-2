package Atividade_8;


public class Main {
    public static void main(String[] args) {

        // Primeira lâmpada
        Lampada lampada1 = new Lampada();
        lampada1.cor = "Branca";
        lampada1.potencia = 60;

        // Segunda lâmpada
        Lampada lampada2 = new Lampada();
        lampada2.cor = "Amarela";
        lampada2.potencia = 40;

        // Configurando o estado das lâmpadas
        lampada1.ligar();
        lampada2.desligar();

        // Exibindo as informações
        lampada1.mostrarEstado();
        lampada2.mostrarEstado();
    }
}

