package Atividade_8;


public class Lampada {

    // Atributos
    String cor;
    int potencia;
    boolean ligada;

    // Método para ligar a lâmpada
    public void ligar() {
        ligada = true;
    }

    // Método para desligar a lâmpada
    public void desligar() {
        ligada = false;
    }

    // Método para mostrar o estado
    public void mostrarEstado() {
        System.out.println("Cor: " + cor);
        System.out.println("Potência: " + potencia + "W");

        if (ligada == true) {
            System.out.println("Estado: Ligada");
        } else {
            System.out.println("Estado: Desligada");
        }

        System.out.println("----------------------");
    }
}

