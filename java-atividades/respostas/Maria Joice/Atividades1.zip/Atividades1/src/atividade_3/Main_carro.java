package atividade_3;

public class Main_carro {
        public static void main(String[] args) {

            // Primeiro carro
            carro carro1 = new carro();
            carro1.modelo = "Corolla";
            carro1.marca = "Toyota";
            carro1.ano = 2022;

            // Segundo carro
            carro carro2 = new carro();
            carro2.modelo = "Civic";
            carro2.marca = "Honda";
            carro2.ano = 2023;

            // Informações do primeiro carro
            carro1.exibirInformacoes();

            // Ligando o primeiro carro
            carro1.ligar();
            carro1.ligar(); // Testando o desafio
            carro1.desligar();

            // Informações do segundo carro
            carro2.exibirInformacoes();

            // Ligando e desligando o segundo carro
            carro2.ligar();
            carro2.desligar();
        }
    }


