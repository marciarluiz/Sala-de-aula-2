package atividade_3;

public class carro {
    // atributos

    String modelo;
    String marca;
    int ano;
    boolean ligado = false;

    // métados para ligar o carro
    public void ligar(){
        if (ligado == false) {
            ligado = true;
            System.out.println("Carro ligado!");
        } else {
            System.out.println("O carro já está ligado!");
        }
    }

    //métado para desligar o carro
    public void desligar(){
        if (ligado == true) {
            ligado = false;
            System.out.println("Carro desligado!");
        } else {
            System.out.println("O carro já está ligado");
        }
    }

    // metodo para exibir informações

    public void exibirInformacoes() {
        System.out.println("Modelo: " + modelo);
        System.out.println("Marca: " + marca);
        System.out.println("Ano: " + ano);
        System.out.println("Ligado: " + ligado);
        System.out.println("----------------------");
    }
}

