package Atividade_10;


public class Calculadora {

    // Método para somar
    public double somar(double a, double b) {
        return a + b;
    }

    // Método para subtrair
    public double subtrair(double a, double b) {
        return a - b;
    }

    // Método para multiplicar
    public double multiplicar(double a, double b) {
        return a * b;
    }

    // Método para dividir
    public double dividir(double a, double b) {
        if (b == 0) {
            System.out.println("Erro: divisão por zero!");
            return Double.NaN;
        } else {
            return a / b;
        }
    }
}
