package Atividade_10;


public class Main {
    public static void main(String[] args) {

        // Criando o objeto
        Calculadora calc = new Calculadora();

        // Realizando as operações
        System.out.println("Soma: " + calc.somar(10, 5));
        System.out.println("Subtração: " + calc.subtrair(10, 5));
        System.out.println("Multiplicação: " + calc.multiplicar(10, 5));
        System.out.println("Divisão: " + calc.dividir(10, 5));

        // Testando o desafio
        calc.dividir(10, 0);
    }
}
