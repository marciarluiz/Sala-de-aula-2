package Atividade_13;


public class ArCondicionado {

    // Atributos
    String marca;
    int temperatura;
    boolean ligado;

    // Método para ligar
    public void ligar() {
        ligado = true;
        System.out.println("Ar-condicionado ligado!");
    }

    // Método para desligar
    public void desligar() {
        ligado = false;
        System.out.println("Ar-condicionado desligado!");
    }

    // Método para aumentar a temperatura
    public void aumentarTemperatura() {
        if (temperatura < 30) {
            temperatura++;
        } else {
            System.out.println("Temperatura máxima atingida!");
        }
    }

    // Método para diminuir a temperatura
    public void diminuirTemperatura() {
        if (temperatura > 16) {
            temperatura--;
        } else {
            System.out.println("Temperatura mínima atingida!");
        }
    }

    // Método para exibir informações
    public void exibirInformacoes() {
        System.out.println("Marca: " + marca);
        System.out.println("Temperatura: " + temperatura + "°C");

        if (ligado == true) {
            System.out.println("Estado: Ligado");
        } else {
            System.out.println("Estado: Desligado");
        }

        System.out.println("----------------------");
    }
}

