package Atividade_13;


public class Main {
    public static void main(String[] args) {

        // Criando o objeto
        ArCondicionado ar = new ArCondicionado();

        // Atribuindo informações
        ar.marca = "Samsung";
        ar.temperatura = 23;
        ar.ligado = false;

        // Ligando o aparelho
        ar.ligar();
        ar.exibirInformacoes();

        // Aumentando a temperatura
        ar.aumentarTemperatura();
        ar.exibirInformacoes();

        // Diminuindo a temperatura
        ar.diminuirTemperatura();
        ar.diminuirTemperatura();
        ar.exibirInformacoes();

        // Desligando o aparelho
        ar.desligar();
        ar.exibirInformacoes();
    }
}

