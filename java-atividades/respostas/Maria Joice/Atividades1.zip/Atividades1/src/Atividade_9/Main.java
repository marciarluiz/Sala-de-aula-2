package Atividade_9;


public class Main {
    public static void main(String[] args) {

        // Primeiro livro
        Livro livro1 = new Livro();
        livro1.titulo = "O Pequeno Príncipe";
        livro1.autor = "Antoine de Saint-Exupéry";
        livro1.paginas = 96;

        // Segundo livro
        Livro livro2 = new Livro();
        livro2.titulo = "Dom Casmurro";
        livro2.autor = "Machado de Assis";
        livro2.paginas = 256;

        // Terceiro livro
        Livro livro3 = new Livro();
        livro3.titulo = "O Hobbit";
        livro3.autor = "J. R. R. Tolkien";
        livro3.paginas = 310;

        // Executando os métodos
        livro1.abrirLivro();
        livro1.mostrarDetalhes();

        livro2.fecharLivro();
        livro2.mostrarDetalhes();

        livro3.abrirLivro();
        livro3.mostrarDetalhes();

        // Fechando o terceiro livro
        livro3.fecharLivro();
        livro3.mostrarDetalhes();
    }
}
