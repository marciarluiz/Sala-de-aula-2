package Atividade_9;


public class Livro {

    // Atributos
    String titulo;
    String autor;
    int paginas;
    boolean aberto;

    // Método para abrir o livro
    public void abrirLivro() {
        aberto = true;
        System.out.println("Livro aberto!");
    }

    // Método para fechar o livro
    public void fecharLivro() {
        aberto = false;
        System.out.println("Livro fechado!");
    }

    // Método para mostrar os detalhes
    public void mostrarDetalhes() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Páginas: " + paginas);

        if (aberto == true) {
            System.out.println("Estado: Aberto");
        } else {
            System.out.println("Estado: Fechado");
        }

        System.out.println("----------------------");
    }
}
