package Atividade_6;


public class Main {
    public static void main(String[] args) {

        // Primeiro cachorro
        Cachorro cachorro1 = new Cachorro();
        cachorro1.nome = "Rex";
        cachorro1.raca = "Pastor Alemão";
        cachorro1.idade = 5;

        // Segundo cachorro
        Cachorro cachorro2 = new Cachorro();
        cachorro2.nome = "Mel";
        cachorro2.raca = "Poodle";
        cachorro2.idade = 3;

        // Terceiro cachorro
        Cachorro cachorro3 = new Cachorro();
        cachorro3.nome = "Bob";
        cachorro3.raca = "Labrador";
        cachorro3.idade = 2;

        // Executando métodos do primeiro cachorro
        cachorro1.exibirDados();
        cachorro1.latir();
        cachorro1.brincar();

        // Executando métodos do segundo cachorro
        cachorro2.exibirDados();
        cachorro2.latir();
        cachorro2.brincar();

        // Executando métodos do terceiro cachorro
        cachorro3.exibirDados();
        cachorro3.latir();
        cachorro3.brincar();
    }
}
