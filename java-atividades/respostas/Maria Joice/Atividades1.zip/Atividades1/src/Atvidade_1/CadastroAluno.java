public class CadastroAluno {
    String nome;
    int idade;
    String curso;
    String matricula;

    public void exibirDados(){
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Curso: " + curso);
        System.out.println("Matricula: " + matricula);

    }

}
