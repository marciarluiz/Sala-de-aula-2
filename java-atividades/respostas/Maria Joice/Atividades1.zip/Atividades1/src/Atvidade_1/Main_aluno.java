public class Main_aluno {
    public static void main(String[] args) {

        // primeiro aluno
       CadastroAluno aluno1 = new CadastroAluno();
       aluno1.nome = "Maria Joice";
       aluno1.idade = 22;
       aluno1.curso = "ADS";
       aluno1.matricula = "20260001";

       // segundo aluno
        CadastroAluno aluno2 = new CadastroAluno();
        aluno2.nome = "João lucas";
        aluno2.idade = 23;
        aluno2.curso = "Ciências da computação";
        aluno2.matricula = "20250012";

        CadastroAluno aluno3 = new CadastroAluno();
        aluno3.nome = "Joana";
        aluno3.idade = 24;
        aluno3.curso = "Sistemas da informação";
        aluno3.matricula = "20250013";

        aluno1.exibirDados();
        aluno2.exibirDados();
        aluno3.exibirDados();


    }
}
