package Atividade_11;


public class Main {
    public static void main(String[] args) {

        // Criando o objeto
        Televisao tv = new Televisao();

        // Atribuindo informações
        tv.marca = "Samsung";
        tv.volume = 20;
        tv.canal = 5;

        // Exibindo informações iniciais
        tv.exibirInformacoes();

        // Aumentando o volume
        tv.aumentarVolume();
        tv.aumentarVolume();

        // Diminuindo o volume
        tv.diminuirVolume();

        // Mudando de canal
        tv.mudarCanal(10);

        // Exibindo informações atualizadas
        tv.exibirInformacoes();
    }
}
