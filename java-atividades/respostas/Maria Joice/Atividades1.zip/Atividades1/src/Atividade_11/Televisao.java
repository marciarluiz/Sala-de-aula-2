package Atividade_11;


public class Televisao {

    // Atributos
    String marca;
    int volume;
    int canal;

    // Método para aumentar o volume
    public void aumentarVolume() {
        if (volume < 100) {
            volume++;
        } else {
            System.out.println("Volume máximo atingido!");
        }
    }

    // Método para diminuir o volume
    public void diminuirVolume() {
        if (volume > 0) {
            volume--;
        } else {
            System.out.println("Volume mínimo atingido!");
        }
    }

    // Método para mudar de canal
    public void mudarCanal(int novoCanal) {
        canal = novoCanal;
    }

    // Método para exibir informações
    public void exibirInformacoes() {
        System.out.println("Marca: " + marca);
        System.out.println("Volume: " + volume);
        System.out.println("Canal: " + canal);
        System.out.println("----------------------");
    }
}
