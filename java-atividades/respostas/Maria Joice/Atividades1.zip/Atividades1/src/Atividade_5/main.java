package Atividade_5;


public class main {
    public static void main(String[] args) {

        // Primeiro celular
        Celular celular1 = new Celular();
        celular1.marca = "Samsung";
        celular1.modelo = "Galaxy S23";
        celular1.bateria = 30;

        // Segundo celular
        Celular celular2 = new Celular();
        celular2.marca = "Apple";
        celular2.modelo = "iPhone 14";
        celular2.bateria = 50;

        // Exibindo informações iniciais
        celular1.exibirInformacoes();
        celular2.exibirInformacoes();

        // Ligando os celulares
        celular1.ligar();
        celular2.ligar();

        // Carregando as baterias
        celular1.carregarBateria();
        celular2.carregarBateria();

        // Exibindo informações atualizadas
        celular1.exibirInformacoes();
        celular2.exibirInformacoes();
    }
}

