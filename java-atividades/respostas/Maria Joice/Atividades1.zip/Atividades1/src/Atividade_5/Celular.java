package Atividade_5;


public class Celular {

    // Atributos
    String marca;
    String modelo;
    int bateria;

    // Método para ligar o celular
    public void ligar() {
        if (bateria > 0) {
            System.out.println("Celular ligado!");
        } else {
            System.out.println("Bateria descarregada!");
        }
    }

    // Método para exibir informações
    public void exibirInformacoes() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Bateria: " + bateria + "%");
        System.out.println("----------------------");
    }

    // Método para carregar a bateria
    public void carregarBateria() {
        bateria = 100;
        System.out.println("Bateria carregada!");
    }
}
