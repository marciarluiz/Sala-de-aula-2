package Atividade_12;


public class Main {
    public static void main(String[] args) {

        // Primeiro produto
        Produto produto1 = new Produto();
        produto1.nome = "Mouse";
        produto1.preco = 50.00;
        produto1.quantidade = 10;

        // Segundo produto
        Produto produto2 = new Produto();
        produto2.nome = "Teclado";
        produto2.preco = 100.00;
        produto2.quantidade = 20;

        // Mostrando o estoque inicial
        produto1.mostrarEstoque();
        produto2.mostrarEstoque();

        // Entrada e saída do primeiro produto
        produto1.adicionarEstoque(5);
        produto1.retirarEstoque(3);

        // Entrada e saída do segundo produto
        produto2.adicionarEstoque(10);
        produto2.retirarEstoque(5);

        // Testando uma retirada inválida
        produto1.retirarEstoque(50);

        // Mostrando o estoque atualizado
        produto1.mostrarEstoque();
        produto2.mostrarEstoque();
    }
}
