package Atividade_12;


public class Produto {

    // Atributos
    String nome;
    double preco;
    int quantidade;

    // Método para adicionar estoque
    public void adicionarEstoque(int quantidade) {
        if (quantidade > 0) {
            this.quantidade += quantidade;
            System.out.println("Estoque adicionado!");
        } else {
            System.out.println("Quantidade inválida!");
        }
    }

    // Método para retirar estoque
    public void retirarEstoque(int quantidade) {
        if (quantidade <= 0) {
            System.out.println("Quantidade inválida!");
        } else if (quantidade <= this.quantidade) {
            this.quantidade -= quantidade;
            System.out.println("Produto retirado!");
        } else {
            System.out.println("Estoque insuficiente!");
        }
    }

    // Método para mostrar o estoque
    public void mostrarEstoque() {
        System.out.println("Nome: " + nome);
        System.out.println("Preço: R$ " + preco);
        System.out.println("Quantidade: " + quantidade);
        System.out.println("----------------------");
    }
}

