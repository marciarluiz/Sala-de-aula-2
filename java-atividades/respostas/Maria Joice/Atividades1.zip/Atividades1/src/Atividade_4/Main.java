package Atividade_4;


public class Main {
    public static void main(String[] args) {

        // Criando os três produtos
        Produto produto1 = new Produto("Notebook", 3000.00, 5);
        Produto produto2 = new Produto("Mouse", 100.00, 10);
        Produto produto3 = new Produto("Teclado", 200.00, 8);

        // Exibindo os produtos
        produto1.exibirProduto();
        produto2.exibirProduto();
        produto3.exibirProduto();

        // Aplicando desconto de 10% no notebook
        produto1.aplicarDesconto(10);

        // Exibindo o notebook após o desconto
        produto1.exibirProduto();
    }
}
