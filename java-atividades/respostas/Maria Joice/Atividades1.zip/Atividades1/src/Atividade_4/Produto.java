package Atividade_4;

public class Produto {
    String nome;
    double preco;
    int quantidade;

    public Produto(String nome, double preco, int quantidade) {
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;

    }

    public double calcularValorEstoque() {
        return preco * quantidade;

    }

    public void exibirProduto() {
        System.out.println("Nome: " + nome);
        System.out.println("Preco: " + preco);
        System.out.println("Quantidade: " + quantidade);
        System.out.println("Valor do estoque: " + calcularValorEstoque());
        System.out.println("----------------------");

    }

    public void aplicarDesconto(double percentual) {
        if (percentual >= 0 && percentual <= 100) {
            preco = preco - (preco * percentual / 100);
            System.out.println("Desconto aplicado!");
        } else {
            System.out.println("Desconto inválido!");
        }
    }
}

