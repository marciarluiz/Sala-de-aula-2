public class Main_conta {
    public static void main(String[] args) {

        ContaBancaria conta1 = new ContaBancaria();
        conta1.titular = "Maria Joice";
        conta1.numeroConta = 123456;
        conta1.saldo = 5000;

        conta1.exibirSaldo();

        conta1.depositar(5000);

        conta1.sacar(200);

        conta1.exibirSaldo();

    }
}
