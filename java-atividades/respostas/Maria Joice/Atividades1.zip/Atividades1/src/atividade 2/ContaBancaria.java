public class ContaBancaria {
    String titular;
    int numeroConta;
    float saldo;

    // metado para depositar dinheiro.
    public void depositar(float valor) {
        if (valor > 0) {
            saldo = saldo + valor;
            System.out.println("Depositado com sucesso");
        } else {
            System.out.println("Saldo invalido");
        }
    }

    // metado para sacar dinheiro.
    public void sacar(float valor) {
        if (valor > 0 && valor <= saldo) {
            saldo = saldo - valor;
            System.out.println("Sacado com sucesso");
        } else {
            System.out.println("Saldo insuficiente");
        }
    }
        void exibirSaldo () {
            System.out.println("Saldo atual R$: " + saldo);

        }
    }
